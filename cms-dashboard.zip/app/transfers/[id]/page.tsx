"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { AuthGuard, useAuth } from "@/components/auth-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  CheckCircle,
  XCircle,
  Clock,
  Package,
  MapPin,
  User,
  Calendar,
  FileText,
  Truck,
  AlertCircle,
  MessageSquare,
  Download,
} from "lucide-react"
import { useParams } from "next/navigation"

// Mock transfer data
const mockTransfer = {
  id: "1",
  contrabandCode: "CMS-001234",
  contrabandType: "Drugs",
  category: "Cocaine",
  quantity: "2.5 kg",
  fromLocation: "Bole Airport",
  toLocation: "Warehouse A",
  requestedBy: "Officer Meron Bekele",
  requestedAt: "2024-01-15T08:30:00",
  approvedBy: "Supervisor Alemayehu Tadesse",
  approvedAt: "2024-01-15T09:15:00",
  receivedBy: "Warehouse Manager Dawit Haile",
  receivedAt: "2024-01-15T11:30:00",
  status: "Completed",
  reason: "Initial storage after seizure at airport customs",
  urgency: "Normal",
  scheduledPickup: "2024-01-15T10:00:00",
  notes: "Item requires temperature-controlled storage. Handle with care.",
  requiresSignature: true,
  timeline: [
    {
      id: "1",
      action: "Transfer Requested",
      actor: "Officer Meron Bekele",
      timestamp: "2024-01-15T08:30:00",
      notes: "Initial storage request after seizure",
      status: "completed",
    },
    {
      id: "2",
      action: "Supervisor Review",
      actor: "Supervisor Alemayehu Tadesse",
      timestamp: "2024-01-15T09:15:00",
      notes: "Approved for immediate transfer to secure storage",
      status: "completed",
    },
    {
      id: "3",
      action: "Pickup Scheduled",
      actor: "System",
      timestamp: "2024-01-15T09:20:00",
      notes: "Warehouse notified of incoming transfer",
      status: "completed",
    },
    {
      id: "4",
      action: "Item Received",
      actor: "Warehouse Manager Dawit Haile",
      timestamp: "2024-01-15T11:30:00",
      notes: "Item received and stored in Section B2",
      status: "completed",
    },
  ],
  attachments: [
    { name: "Transfer Authorization.pdf", size: "245 KB", type: "pdf" },
    { name: "Item Photos.zip", size: "1.2 MB", type: "zip" },
  ],
}

export default function TransferDetailPage() {
  const { user } = useAuth()
  const params = useParams()
  const [currentPath] = useState(`/transfers/${params.id}`)
  const [approvalNotes, setApprovalNotes] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const handleApproval = async (approved: boolean) => {
    setIsProcessing(true)
    try {
      // Mock API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      console.log(`Transfer ${approved ? "approved" : "rejected"}:`, approvalNotes)
    } catch (error) {
      console.error("Approval failed:", error)
    } finally {
      setIsProcessing(false)
    }
  }

  const handleReceipt = async () => {
    setIsProcessing(true)
    try {
      // Mock API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      console.log("Transfer receipt acknowledged")
    } catch (error) {
      console.error("Receipt acknowledgment failed:", error)
    } finally {
      setIsProcessing(false)
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  const canApprove = (user.role === "Supervisor" || user.role === "Admin") && mockTransfer.status === "Pending"
  const canReceive = (user.role === "Warehouse Manager" || user.role === "Admin") && mockTransfer.status === "Approved"

  return (
    <AuthGuard>
      <div className="min-h-screen bg-background">
        <DashboardHeader userRole={user.role} userName={user.name} notificationCount={7} />

        <div className="flex h-[calc(100vh-4rem)]">
          <DashboardSidebar userRole={user.role} currentPath={currentPath} />

          <main className="flex-1 overflow-auto">
            <div className="container mx-auto p-6 space-y-6">
              {/* Header */}
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-foreground">Transfer #{mockTransfer.id}</h1>
                  <div className="flex items-center space-x-4 mt-2">
                    <Badge className="bg-gray-500 text-white">{mockTransfer.status}</Badge>
                    <Badge
                      className={mockTransfer.urgency === "Urgent" ? "bg-red-500 text-white" : "bg-gray-500 text-white"}
                    >
                      {mockTransfer.urgency}
                    </Badge>
                    <span className="text-muted-foreground">Item: {mockTransfer.contrabandCode}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Export Report
                  </Button>
                </div>
              </div>

              {/* Action Alerts */}
              {canApprove && (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>This transfer request requires your approval as a supervisor.</AlertDescription>
                </Alert>
              )}

              {canReceive && (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>This approved transfer is ready for receipt acknowledgment.</AlertDescription>
                </Alert>
              )}

              <div className="grid gap-6 lg:grid-cols-3">
                {/* Main Content - 2 columns */}
                <div className="lg:col-span-2 space-y-6">
                  {/* Transfer Summary */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Transfer Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div>
                            <label className="text-sm font-medium text-muted-foreground">Item Details</label>
                            <div className="flex items-center space-x-3 mt-1">
                              <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                                <Package className="h-5 w-5 text-muted-foreground" />
                              </div>
                              <div>
                                <p className="font-mono text-sm">{mockTransfer.contrabandCode}</p>
                                <p className="text-sm text-muted-foreground">
                                  {mockTransfer.contrabandType} - {mockTransfer.category}
                                </p>
                                <p className="text-sm font-medium">{mockTransfer.quantity}</p>
                              </div>
                            </div>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-muted-foreground">Transfer Route</label>
                            <div className="mt-1 space-y-2">
                              <div className="flex items-center text-sm">
                                <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                                <span className="font-medium">From:</span>
                                <span className="ml-2">{mockTransfer.fromLocation}</span>
                              </div>
                              <div className="flex items-center text-sm">
                                <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                                <span className="font-medium">To:</span>
                                <span className="ml-2">{mockTransfer.toLocation}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="space-y-4">
                          <div>
                            <label className="text-sm font-medium text-muted-foreground">Requested By</label>
                            <p className="text-sm flex items-center mt-1">
                              <User className="h-4 w-4 mr-2" />
                              {mockTransfer.requestedBy}
                            </p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-muted-foreground">Request Date</label>
                            <p className="text-sm flex items-center mt-1">
                              <Calendar className="h-4 w-4 mr-2" />
                              {new Date(mockTransfer.requestedAt).toLocaleString()}
                            </p>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-muted-foreground">Scheduled Pickup</label>
                            <p className="text-sm flex items-center mt-1">
                              <Clock className="h-4 w-4 mr-2" />
                              {new Date(mockTransfer.scheduledPickup).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      </div>
                      <Separator className="my-4" />
                      <div>
                        <label className="text-sm font-medium text-muted-foreground">Reason for Transfer</label>
                        <p className="text-sm mt-1">{mockTransfer.reason}</p>
                      </div>
                      {mockTransfer.notes && (
                        <>
                          <Separator className="my-4" />
                          <div>
                            <label className="text-sm font-medium text-muted-foreground">Additional Notes</label>
                            <p className="text-sm mt-1">{mockTransfer.notes}</p>
                          </div>
                        </>
                      )}
                    </CardContent>
                  </Card>

                  {/* Tabs for detailed information */}
                  <Tabs defaultValue="timeline" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="timeline">Timeline</TabsTrigger>
                      <TabsTrigger value="attachments">Attachments</TabsTrigger>
                      <TabsTrigger value="signatures">Signatures</TabsTrigger>
                    </TabsList>

                    <TabsContent value="timeline" className="space-y-4">
                      <Card>
                        <CardHeader>
                          <CardTitle>Transfer Timeline</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            {mockTransfer.timeline.map((event, index) => (
                              <div key={event.id} className="flex items-start space-x-4">
                                <div className="flex flex-col items-center">
                                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                                    {event.status === "completed" ? (
                                      <CheckCircle className="h-4 w-4 text-green-500" />
                                    ) : (
                                      <Clock className="h-4 w-4 text-blue-500" />
                                    )}
                                  </div>
                                  {index < mockTransfer.timeline.length - 1 && (
                                    <div className="w-px h-8 bg-border mt-2" />
                                  )}
                                </div>
                                <div className="flex-1 pb-4">
                                  <div className="flex items-center justify-between">
                                    <h4 className="font-medium">{event.action}</h4>
                                    <span className="text-sm text-muted-foreground">
                                      {new Date(event.timestamp).toLocaleString()}
                                    </span>
                                  </div>
                                  <p className="text-sm text-muted-foreground mt-1">By {event.actor}</p>
                                  <p className="text-sm mt-2">{event.notes}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>

                    <TabsContent value="attachments" className="space-y-4">
                      <Card>
                        <CardHeader>
                          <CardTitle>Attachments ({mockTransfer.attachments.length})</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {mockTransfer.attachments.map((attachment, index) => (
                              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                                <div className="flex items-center space-x-3">
                                  <FileText className="h-5 w-5 text-muted-foreground" />
                                  <div>
                                    <p className="font-medium">{attachment.name}</p>
                                    <p className="text-sm text-muted-foreground">{attachment.size}</p>
                                  </div>
                                </div>
                                <Button variant="ghost" size="sm">
                                  <Download className="h-4 w-4" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>

                    <TabsContent value="signatures" className="space-y-4">
                      <Card>
                        <CardHeader>
                          <CardTitle>Digital Signatures</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div className="flex items-center justify-between p-4 border rounded-lg">
                              <div>
                                <h4 className="font-medium">Requester Signature</h4>
                                <p className="text-sm text-muted-foreground">Officer Meron Bekele</p>
                                <p className="text-xs text-muted-foreground">
                                  Signed: {new Date(mockTransfer.requestedAt).toLocaleString()}
                                </p>
                              </div>
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            </div>
                            <div className="flex items-center justify-between p-4 border rounded-lg">
                              <div>
                                <h4 className="font-medium">Supervisor Approval</h4>
                                <p className="text-sm text-muted-foreground">Supervisor Alemayehu Tadesse</p>
                                <p className="text-xs text-muted-foreground">
                                  Signed: {new Date(mockTransfer.approvedAt).toLocaleString()}
                                </p>
                              </div>
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            </div>
                            <div className="flex items-center justify-between p-4 border rounded-lg">
                              <div>
                                <h4 className="font-medium">Receiver Acknowledgment</h4>
                                <p className="text-sm text-muted-foreground">Warehouse Manager Dawit Haile</p>
                                <p className="text-xs text-muted-foreground">
                                  Signed: {new Date(mockTransfer.receivedAt).toLocaleString()}
                                </p>
                              </div>
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>
                  </Tabs>
                </div>

                {/* Sidebar - 1 column */}
                <div className="space-y-6">
                  {/* Action Panel */}
                  {(canApprove || canReceive) && (
                    <Card>
                      <CardHeader>
                        <CardTitle>{canApprove ? "Approval Required" : "Receipt Acknowledgment"}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {canApprove && (
                          <>
                            <div className="space-y-2">
                              <Label htmlFor="approvalNotes">Approval Notes</Label>
                              <Textarea
                                id="approvalNotes"
                                value={approvalNotes}
                                onChange={(e) => setApprovalNotes(e.target.value)}
                                placeholder="Add notes about your decision..."
                                rows={3}
                              />
                            </div>
                            <div className="flex space-x-2">
                              <Button onClick={() => handleApproval(true)} disabled={isProcessing} className="flex-1">
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Approve
                              </Button>
                              <Button
                                onClick={() => handleApproval(false)}
                                disabled={isProcessing}
                                variant="destructive"
                                className="flex-1"
                              >
                                <XCircle className="h-4 w-4 mr-2" />
                                Reject
                              </Button>
                            </div>
                          </>
                        )}

                        {canReceive && (
                          <Button onClick={handleReceipt} disabled={isProcessing} className="w-full">
                            <Truck className="h-4 w-4 mr-2" />
                            {isProcessing ? "Processing..." : "Acknowledge Receipt"}
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {/* Transfer Status */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Transfer Status</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Current Status</span>
                        <Badge className="bg-gray-500 text-white">{mockTransfer.status}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Urgency</span>
                        <Badge
                          className={
                            mockTransfer.urgency === "Urgent" ? "bg-red-500 text-white" : "bg-gray-500 text-white"
                          }
                        >
                          {mockTransfer.urgency}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Signature Required</span>
                        <Badge variant="outline">{mockTransfer.requiresSignature ? "Yes" : "No"}</Badge>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Quick Actions */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Quick Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <Button variant="outline" className="w-full bg-transparent">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Add Comment
                      </Button>
                      <Button variant="outline" className="w-full bg-transparent">
                        <FileText className="h-4 w-4 mr-2" />
                        Generate Report
                      </Button>
                      <Button variant="outline" className="w-full bg-transparent">
                        <Download className="h-4 w-4 mr-2" />
                        Export Timeline
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </AuthGuard>
  )
}
